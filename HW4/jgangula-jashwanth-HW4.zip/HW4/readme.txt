The graph implementation contains the csv files and the adjaceny list
is created from it. Both the directed and undirected graphs can be constructed 
based on adjacency matrix created.
The dijkstra alogirthm which is greedy based inserts a new
vertex into the set, uses the priority queue to update the distances of
popped vertcies at each stage. All the dot files were generated to verify the 
implementation. The vertices were named as string used a map to convert the name to 
vertex numbers for ease of implementation
